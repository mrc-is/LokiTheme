(function (nfield, $, ko) {
    var QHelper = function (id) {
        var result = ko.utils.arrayFirst(nfield.currentBlock.questions,
            function (question) {
                return question.id === id;
            });
        if (!result) {
            result = new nfield.Question();
            result.id = id;
            var data = $('#' + id);
            if (data.length > 0)
                result.answers.push(data.val());
        }
        return result;
    };
    var operators = {
            Q: QHelper,
            N: function(number) {
                return new Number(number);
            },
            T: function(text) {
                return new String(text);
            },
            R: function(rangeExpression) {
                var range = rangeExpression.split(";");
                var start = range[0];
                var end = range[1];

                var result = [];
                for (var i = start; i <= end; i++) {
                    result.push(i.toString());
                }

                return result;
            },
            Range: function (rangeExpression) {
                var range = rangeExpression.split(";");
                var left = range[0];
                var right = range[1];

                left = parseInt(convertToPrimitive(left));
                right = parseInt(convertToPrimitive(right));

                var result = [];
                for (var i = left; i <= right; i++) {
                    result.push(i.toString());
                }

                return result;

            },
            C: function(codesList) {
                var codesArray = codesList.split(";");
                var questionWrapper = new nfield.Question();
                questionWrapper.answers(codesArray);
                questionWrapper.isMulti = true;
                return questionWrapper;
            },
            And: function(left, right) {
                if (left && right)
                    return new Number(1);
                else
                    return new Number(0);
            },
            Or: function(left, right) {
                if (left || right)
                    return new Number(1);
                else
                    return new Number(0);
            },
            Equal: function (left, right) {
                // Equality check with data conversion (==). The expectation is that ODIN and javascript behave similarly here.
                if (left == right)
                    return new Number(1);
                else
                    return new Number(0);
            },
            NotEqual: function (left, right) {
                // UnEquality check with data conversion(!=). The expectation is that ODIN and javascript behave similarly here.
                if (left != right)
                    return new Number(1);
                else
                    return new Number(0);
            },
            LessOrEqual: function (left, right) {
                if (left <= right)
                    return new Number(1);
                else
                    return new Number(0);
            },
            GreaterOrEqual: function(left, right) {
                if (left >= right)
                    return new Number(1);
                else
                    return new Number(0);
            },
            LessThan: function (left, right) {
                if (left < right)
                    return new Number(1);
                else
                    return new Number(0);
            },
            GreaterThan: function(left, right) {
                if (left > right)
                    return new Number(1);
                else
                    return new Number(0);
            },
            Add: function(left, right) {
                return new Number(parseInt(left) + parseInt(right));
            },
            Subtract: function(left, right) {
                return new Number(parseInt(left) - parseInt(right));
            },
            Multiply: function(left, right) {
                return new Number(parseInt(left) * parseInt(right));
            },
            Divide: function(left, right) {
                return new Number(parseInt(left) / parseInt(right));
            },
            Modulus: function (random, max) {
                var result = parseInt(max) === 0 ? 0 : parseInt(random) % parseInt(max);
                return new Number(result);
            },
            Not: function (operand) {
                operandPrimitive = convertToPrimitive(operand);
                operandBoolean = convertToBoolean(operandPrimitive);
                operandBoolean = !operandBoolean;   // Apply the NOT logic

                if (operandBoolean) {
                    return new Number(1);
                } else {
                    return new Number(0);
                }
            },
            Negate: function(operand) {
                operand = convertToPrimitive(operand);

                return new Number(-1 * parseInt(operand));
            },
            StringLength: function(text) {
                var string = text.toString();
                return new Number(string.length);
            },
            SemiColon: function (left, right) {
                if (!(left instanceof Array)) {
                    var leftValue = parseInt(convertToPrimitive(left));
                    left = [leftValue.toString()];
                }

                if (!(right instanceof Array)) {
                    var rightValue = parseInt(convertToPrimitive(right));
                    right = [rightValue.toString()];
                }

                return left.concat(right);
            },
            FormField: function (question, formIndex) {
                if (question instanceof nfield.Question) {
                    return QHelper(question.id + 'f' + formIndex);
                }
                return new nfield.Question();
            },
            MatrixStatement: function (question, index) {
                if (question instanceof nfield.Question) {
                    var rIndex = question.id.lastIndexOf('r');
                    var qIndex = question.id.lastIndexOf('q');
                    if (rIndex != -1 && rIndex < qIndex) {
                        return QHelper(question.id.substring(0, rIndex + 1) + index + question.id.substring(qIndex));
                    }
                    return QHelper('r' + index +  question.id);
                }
                return new nfield.Question();
            },
            Code: function (left, right) {
                var answers;
                if (left instanceof CodeResult) {
                    if (left.result)
                        return left;
                    answers = left.answers;
                }
                else if (left instanceof nfield.Question) {
                    answers = left.answers();
                } else {
                    answers = [left.valueOf().toString()];
                }

                if (right instanceof Array) {
                    // Code with range
                    for (var i = 0; i < right.length; i++) {
                        if (answers.indexOf(right[i]) > -1) {
                            return new CodeResult(answers, true);
                        }
                    }
                    return new CodeResult(answers, false);
                }

                if (right instanceof Number ||
                    right instanceof nfield.Question ||
                    right instanceof String) {

                    var rightValue = right.valueOf();
                    if (rightValue !== null &&
                        typeof(rightValue) !== "undefined" &&
                        answers.indexOf(rightValue.toString()) > -1) {
                        return new CodeResult(answers, true);
                    }
                }
                return new CodeResult(answers, false);
            }
        },
        // Ctor. Represents a result of a Code operation
        CodeResult = function (answers, result) {
            var self = this;

            self.answers = answers;
            self.result = result;
        },
        // Converts an object to a primitive value
        convertToPrimitive = function(object) {
            while (object === Object(object)) {
                object = object.valueOf();
            }

            // At this point the variable is a primitive type
            return object;
        },
        // Converts a value to a boolean - the ODIN way
        convertToBoolean = function (result) {
            var resultNum = parseInt(result);
            if (isNaN(resultNum))
                return false;

            if (resultNum === 0)
                return false;

            return true;
        },
        // Aspect Oriented Programming. Operator function is augmented into a new function that first converts the operands into primitives.
        operatorOfPrimitives = function (operatorFn) {
            return function(left, right) {
                left = convertToPrimitive(left);
                right = convertToPrimitive(right);

                return operatorFn(left, right);
            }
        };

    CodeResult.prototype.valueOf = function () {
        if (this.result) {
            return new Number(1);
        }
        else {
            return new Number(0);
        }
    };

    $.extend(nfield, { Operators: {
        Q: operators.Q,
        N: operators.N,
        T: operators.T,
        R: operators.R,
        Range: operators.Range,
        C: operators.C,
        And: operatorOfPrimitives(operators.And),
        Or: operatorOfPrimitives(operators.Or),
        Equal: operatorOfPrimitives(operators.Equal),
        NotEqual: operatorOfPrimitives(operators.NotEqual),
        LessOrEqual: operatorOfPrimitives(operators.LessOrEqual),
        GreaterOrEqual: operatorOfPrimitives(operators.GreaterOrEqual),
        LessThan: operatorOfPrimitives(operators.LessThan),
        GreaterThan: operatorOfPrimitives(operators.GreaterThan),
        Add: operatorOfPrimitives(operators.Add),
        Subtract: operatorOfPrimitives(operators.Subtract),
        Multiply: operatorOfPrimitives(operators.Multiply),
        Divide: operatorOfPrimitives(operators.Divide),
        Not: operators.Not,
        Negate: operators.Negate,
        StringLength: operators.StringLength,
        SemiColon: operators.SemiColon,
        Code: operators.Code,
        FormField: operators.FormField,
        Modulus: operatorOfPrimitives(operators.Modulus)
    } });

})(NFIELD, jQuery, ko);
