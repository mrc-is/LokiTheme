﻿/*
*  Numeric input jQuery-plugin for Nfield
*
*  Copyright (c) NIPO Software 2011
*/
(function ($) {

    var methods =
    {

        init: function (options) {

            var settings =
            {
                'numberOfDecimals': 1,
                'fractionLength': 0,
                'defaultMinimum': 0
            }; // settings

            return this.each(function () {
                if (options) {
                    $.extend(settings, options);
                }

                if (!settings['maximum']) {
                    // no maximum defined, calculate maximum based on numberOfDecimals
                    var maximum = 1;
                    var numberOfDecimals = settings['numberOfDecimals'];
                    for (var i = 0; i < numberOfDecimals; ++i) {
                        maximum = maximum * 10;
                    }
                    var fractionSubstract = 1;
                    var fractionLength = settings['fractionLength'];
                    for (var i = 0; i < fractionLength; ++i) {
                        fractionSubstract = fractionSubstract * 0.1;
                    }
                    maximum = maximum - fractionSubstract;

                    // add the calculated maximum to the settings
                    $.extend(settings, { 'maximum': maximum });
                } // maximum

                if (!settings['minimum']) {
                    // no minimum defined, set minimum to defaultMinimum
                    var minimum = settings['defaultMinimum'];

                    // add the minimum to the settings
                    $.extend(settings, { 'minimum': minimum });
                } // minimum

                var $this = $(this);

                var inputLength = settings['numberOfDecimals'] + settings['fractionLength'];
                if (settings['fractionLength'] > 0) {
                    inputLength = inputLength + 1;
                }
                if (settings['minimum'] < 0) {
                    inputLength = inputLength + 1;
                }
                $this.attr('maxlength', inputLength);
            }); // return

        } // init

    }; // methods

    $.fn.nfieldNumeric = function (method) {
        if (methods[method]) {
            return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
        }
        else if (typeof method === 'object' || !method) {
            return methods.init.apply(this, arguments);
        }
        else {
            $.error('Method ' + method + ' does not exist on jQuery.nfieldNumeric');
        }

    }; // nfieldNumeric

})(jQuery);

$(document).ready(function () {
    $("input.open.number").each(function () {
        var $this = $(this);

        var numberOfDecimals = parseInt($this.attr("data-number-of-decimals"));
        var fractionLength = parseInt($this.attr("data-fraction-length"));
        var minValue = parseInt($this.attr("data-minimum"));
        var maxValue = parseInt($this.attr("data-maximum"));

        $this.nfieldNumeric({ "numberOfDecimals": numberOfDecimals, "fractionLength": fractionLength, "minimum": minValue, "maximum": maxValue });
    });
});