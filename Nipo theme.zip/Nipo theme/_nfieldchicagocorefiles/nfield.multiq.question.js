(function (nfield, $, ko) {
    setCodeDataAndHandlers = function ($segment, onClick) {
        var categories = $segment.find(".categorygroup > .category");
        categories.bind("asifclicked", onClick);
        categories = $segment.find(".categorygroup > .category.selected");
        categories.trigger("asifclicked");
    },
    addOptionsAndHandlers = function ($segment, self) {
        if (self.isMulti) {
            var onClick = function () {
                var $input = $("input", this);
                var value = $input.val().split("-").pop();
                if ($input.is(":checked")) {
                    self.answers.push(value);
                } else {
                    self.answers.remove(value);
                }
                nfield.changeTracker.triggerChange();
            };
            setCodeDataAndHandlers($segment, onClick);
        } else if (self.isCode) {
            var onClick = function () {
                var $input = $("input", this);
                var value = $input.val().split("-").pop();
                self.answers().length = 0;
                if ($input.is(":checked")) {
                    self.answers.push(value);
                }
                nfield.changeTracker.triggerChange();
            };
            setCodeDataAndHandlers($segment, onClick);
        } else if (self.isOpen) {
            // Attach an handler for the open questionnaire and update its answers.
            var onChange = function () {
                var $input = $(this);
                var value = $input.val();
                self.answers().length = 0;
                self.answers.push(value);
                nfield.changeTracker.triggerChange();
            };
            var inputItem = $segment.find("textarea");
            inputItem.on("keyup", onChange);
            inputItem.bind("asifclicked", onChange);
            inputItem.trigger("asifclicked");
        } else if (self.isNumber) {
            // Attach an handler for the open questionnaire and update its answers.
            var onChange = function () {
                var $input = $(this);
                var value = $input.val();
                self.answers().length = 0;
                self.answers.push(value);
                nfield.changeTracker.triggerChange();
            };
            var inputItem = $segment.find("input.number");
            inputItem.on("keyup", onChange);
            inputItem.bind("asifclicked", onChange);
            inputItem.trigger("asifclicked");
        }
    },
    question = function ($segment) {
        var self = this;

        self.id = null;
        self.isMulti = false;
        self.isCode = false;
        self.isOpen = false;
        self.isNumber = false;
        self.answers = ko.observableArray([]);

        if ($segment !== null && typeof ($segment) !== "undefined") {
            self.id = $segment.attr("id");
            if (self.id) {
                var idSplit = self.id.split("-");
                if (idSplit.length > 1) {
                    self.id = idSplit[1];
                }
            }
            self.isMulti = $segment.find(".category.multi").length > 0;
            self.isCode = $segment.find("input:radio, input:checkbox").length > 0;
            self.isOpen = $segment.find("textarea").length > 0;
            self.isNumber = $segment.find("input.number").length > 0;
            addOptionsAndHandlers($segment, self);
        }
    };

    question.prototype.valueOf = function () {
        if (this.answers().length === 0)
            return null;

        if (this.isMulti) {
            return Math.max.apply(Math, this.answers());
        }

        return this.answers()[0];
    };

    $.extend(nfield, { Question: question });

})(NFIELD || {}, jQuery, ko);
