var NFIELD = NFIELD || {};

(function (nfield, $) {

    var createQuestionnaireModel = function ($context) {
        var $domObject = $context.first();
        var model = new nfield.QuestionnaireModel($domObject);

        return model;
    }

    $.extend(nfield, { createQuestionnaireModel: createQuestionnaireModel });

})(NFIELD, jQuery);


// Build the currentBlock model when the page is ready
$(function () {
    NFIELD.currentBlock = NFIELD.createQuestionnaireModel($('form'));

    ko.applyBindings(NFIELD.currentBlock);

    // Run the expressions for the first time
//    NFIELD.changeTracker.triggerChange();
});