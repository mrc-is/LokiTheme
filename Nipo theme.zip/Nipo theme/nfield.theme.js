var theme = {};

theme.init = function() {
    var customProgress = parseInt($('*[data-progress]').data('progress'));
    if (customProgress > 0) {
        $("#progress").removeAttr("style").width(customProgress + "%");
    }
	 $(".complete .btn.button-clear").remove();
	 theme.functions.injectHTML();
}
theme.functions = {
 // allow the injection of HTML from texts in Odin script where the html is defined between [HTML] and [/HTML]
 // for example: do you see [HTML]<hr>[/HTML] the horizontal line here 
 injectHTML: function() {
  var paragraphs =  $('.segment.active span');
  paragraphs.each(function() {
   var $this = $(this);
   if ($this.html().indexOf('[HTML]') !== -1) {
    var newhtml=$this.parent().html().replace(/\[HTML\]/g,'\<\/span\>').replace(/\[\/HTML\]/g, '\<span class="injected"\>').replace(/&lt;/g, '<').replace(/&gt;/g, '>') ;
    $this.parent().html(newhtml);
    $(".injected").attr("class", $this.attr("class"));
   }
  })
 }
}
