(function (nfield, $, ko) {
    var questionnaireModel = function ($context) {
        var self = this;

        var convertExpressionResultToBoolean = function (result) {
            var resultNum = parseInt(result);
            if (isNaN(resultNum))
                return false;

            if (resultNum === 0)
                return false;

            return true;
        };

        self.questions = [];

        self.isVisible = function (item) {
            var $item = $(item);

            var categories = $item.find("div.category,div.container");
            if (categories.length > 0) {
                nfield.changeTracker.seed();
                var visible = false;
                categories.each(function () {
                    visible = self.isVisible(this);
                    return !visible;
                });
                if (!visible) // none of the categories are visible
                    return false;
            }

            var expression = $item.attr("data-expression");
            if (!expression || expression.length === 0) {
                return true;
            }
            // @hakant: in order  to create a dependency for knockout (is there a better way of doing this?)
            nfield.changeTracker.seed();

            var result = eval(expression.toString()).valueOf();
            return convertExpressionResultToBoolean(result);
        };

        self.load($context);
    }

    questionnaireModel.prototype.load = function($context) {
        var self = this;
        $context.find(".segment.active").each(function () {
            self.questions.push(new nfield.Question($(this), self));
        });
    };

    questionnaireModel.prototype.clearAllAnswers = function() {
        var self = this;
        $.each(self.questions, function(index, item) {
            item.clearAnswers();
        });
    };

    var changeTracker = function () {
        var self = this;

        self.seed = ko.observable(0);
        self.triggerChange = function() {
            self.seed(self.seed() + 1);
        };
    };

    $.extend(nfield, { QuestionnaireModel: questionnaireModel, changeTracker: new changeTracker() });

})(NFIELD || {}, jQuery, ko);
