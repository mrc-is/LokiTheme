/*
*  Contains validation functions for all question types
*
*  Copyright (c) NIPO Software 2013
*/
console.log('Custom validation loaded.');

var NFIELD = NFIELD || {};

(function (nfield, $) {
    var validateOpenCategory = function($categoryOpen) {
        if (typeof ErrorMessages != "undefined") {
            if ($categoryOpen.val() === '') {
                {
                    var $category = $categoryOpen.closest(".category");
                    var checked = false;
                    $("input.category", $category).each(function() {
                        if (this.checked === true) {
                            checked = true;
                        }
                    });

                    if (checked) {
                        return { "valid": false, "message": ErrorMessages.AnswerRequired };
                    }
                }
            }
        }
        return { "valid": true, "message": "" };
    },
        validateRequiredOnOpen = function($open) {
            if (typeof ErrorMessages != "undefined") {
                if ($open.val() === '') {
                    return { "valid": false, "message": ErrorMessages.AnswerRequired };
                }
            }

            return { "valid": true, "message": "" };
        },
        validateOpenForUserButton = function ($open, $target) {
            if (typeof ErrorMessages != "undefined") {
                var message = '';
                if (typeof $target !== 'undefined') {
                    var buttonName = $target.val();
                     message = ErrorMessages.DoNotUseButtonWithOtherAnswer.replace('{item}', buttonName);
                }

                if ($open.val() !== '') {
                    return { "valid": false, "message": message };
                }
            }

            return { "valid": true, "message": "" };
        },
        validateRequiredOnCategoryList = function($list) {

            if (typeof ErrorMessages != "undefined") {
                var result = false;
                var message = ErrorMessages.AnswerRequired;

                $("input.category", $list).each(function () {
                    if (this.checked === true) {
                        result = true;
                        message = "";
                    }
                });

                return { "valid": result, "message": message };
            }

            return { "valid": true, "message": "" };
        },
        validateCategoryListForUserButton = function ($list, $target) {
            if (typeof ErrorMessages != "undefined") {
                var result = true;
                var message = '';
                if (typeof $target !== 'undefined') {
                    var buttonName = $target.val();
                    message = ErrorMessages.DoNotUseButtonWithOtherAnswer.replace('{item}', buttonName);
                }
                
                $("input.category", $list).each(function () {
                    if (this.checked === true) {
                        result = false;
                    }
                });

                return { "valid": result, "message": message };
            }

            return { "valid": true, "message": "" };
        },
        validateValidNumberOnOpenNumeric = function($open) {
            if (typeof ErrorMessages != "undefined") {
                var inputValue = $open.val().replace(' ', '');

                if (inputValue != $open.val())
                    $open.val(inputValue);

                // don't use \d because superscript numbers also match
                if (!inputValue.match(/^-?([\x30-\x39]*)\.?([\x30-\x39]*$)/gi))
                    return { "valid": false, "message": ErrorMessages.MustBeNumeric.replace("{answer}", inputValue) };
            }

            return { "valid": true, "message": "" };
        },
        validateFractionLengthOnOpenNumeric = function($open) {
            if (typeof ErrorMessages != "undefined") {
                var inputValue = $open.val().replace(' ', '');

                if (inputValue != $open.val())
                    $open.val(inputValue);

                var numFraction = parseInt($open.attr("data-fraction-length"));
                var matchString = '^-?(\\d*)$';

                if (numFraction > 0)
                    matchString = '(^-?(\\d*)$)|(^-{0,1}(\\d*).\\d{0,' + numFraction + '}$)';

                if (!inputValue.match(new RegExp(matchString, 'gi')))
                    return {
                        "valid": false,
                        "message": ErrorMessages.TooManyDigitsFraction.replace("{answer}", inputValue).replace("{maximumDigits}", numFraction)
                    };
            }

            return { "valid": true, "message": "" };
        },
        validateMinMaxOnOpenNumeric = function($open) {
            var validationResult = true;
            var rangeValidationMessage = "";

            if (typeof ErrorMessages != "undefined") {
                var inputString = $open.val();

                if (inputString !== null && inputString !== "") {

                    var inputValue = parseFloat(inputString);
                    var minValue = parseFloat($open.attr("data-minimum"));
                    var maxValue = parseFloat($open.attr("data-maximum"));

                    if (minValue != null && inputValue < minValue) {
                        validationResult = false;
                        rangeValidationMessage = ErrorMessages.LessThanMinimum.replace("{minimum}", minValue).replace("{answer}", inputValue);
                    }

                    if (maxValue != null && inputValue > maxValue) {
                        validationResult = false;
                        rangeValidationMessage = ErrorMessages.MoreThanMaximum.replace("{maximum}", maxValue).replace("{answer}", inputValue);
                    }
                }
            }

            return { "valid": validationResult, "message": rangeValidationMessage };
        },
        validateRangeOnOpenNumeric = function($open) {
            var validationResult = true;
            var rangeValidationMessage = "";

            if (typeof ErrorMessages != "undefined") {
                var inputString = $open.val();

                if (inputString !== null && inputString !== "") {
                    var rangeValue = $open.attr("data-range");

                    if (rangeValue === "")
                        return { "valid": true, "message": "" };

                    validationResult = false;

                    var inputValue = parseInt(inputString);
                    var ranges = rangeValue.split(';');

                    for (var i = 0; i < ranges.length; i++) {
                        var range = ranges[i].split('to');

                        if (range.length == 2 && inputValue >= parseInt(range[0]) && inputValue <= parseInt(range[1])) { // the TO range
                            validationResult = true;
                            break;
                        }

                        if (inputValue == parseInt(range[0])) { // single value
                            validationResult = true;
                            break;
                        }
                    }

                    if (!validationResult) {
                        rangeValidationMessage = ErrorMessages.NotInRange.replace("{answer}", inputValue).replace("{range}", rangeValue.replace("to", "-"));
                    }
                }
            }

            return { "valid": validationResult, "message": rangeValidationMessage };
        },
        validateMinMaxOnCategoryList = function($list) {
            if (typeof ErrorMessages != "undefined") {
                var validationResult = false;
                var rangeValidationMessage = "";
                var checkedCount = 0;
                var minValue = 0;
                var maxValue = 0;

                if ($list.attr("data-minimum") != null) {
                    minValue = parseInt($list.attr("data-minimum"));
                }

                if ($list.attr("data-maximum") != null) {
                    maxValue = parseInt($list.attr("data-maximum"));
                }

                if (minValue == 0 && maxValue == 0) {
                    return { "valid": true, "message": "" };
                }
                var exclusiveSelected = false;

                $("input.category", $list).each(function() {
                    if (this.checked === true) {
                        var $category = $(this);
                        if ($category.attr("type") === "radio") {
                            exclusiveSelected = true;
                        }
                        checkedCount++;
                    }
                });

                if (exclusiveSelected || (checkedCount == 0 && $list.hasClass("optional"))) {
                    return { "valid": true, "message": "" };
                }

                if ((minValue > 0 && checkedCount < minValue) || (maxValue > 0 && checkedCount > maxValue)) {
                    if (checkedCount < minValue) {
                        rangeValidationMessage = ErrorMessages.TooFewAnswers.replace("{minimum}", minValue);
                    } else {
                        rangeValidationMessage = ErrorMessages.TooManyAnswers.replace("{maximum}", maxValue);
                    }
                } else {
                    validationResult = true;
                }

                return { "valid": validationResult, "message": rangeValidationMessage };
            }

            return { "valid": true, "message": "" };
        },
        validate = function(selector, validateFunction, target) {
            /// <summary>
            /// Calls the validateFunction for each item that matches the selector.
            /// The validateFunction is required to return an object with two properties.
            /// A boolean 'valid' and a string 'message'.
            /// </summary>
            /// <param name="selector" type="String">The selector to match</param>
            /// <param name="validateFunction" type="Function">The function that does the actual validation.</param>
            /// <returns type="Boolean">Whether all items matching the selctor were valid.</returns>

            var result = true;
            $(selector).each(function() {

                if (!result)
                    return;

                var $item = $(this);
                var $segment = $item.closest(".segment.active");
                var validationClosure = function() {
                    if (validateFunction($item).valid) {
                        $(".validation-message .message", $segment).text('');
                        $(".validation-message", $segment).slideUp().removeClass("error");
                        $item.unbind("blur");
                        $("input", $item).unbind("change");
                    }
                };

                var validationResult = validateFunction($item, target);
                if (!validationResult.valid) {
                    if ($item.hasClass('categorylist')) {
                        $("input", $item).bind("change", validationClosure);
                    } else {
                        $item.bind("blur", validationClosure);
                    }
                    
                    $(".validation-message .message", $segment).text(validationResult.message);
                    $(".validation-message", $segment).fadeIn().addClass("error");

                    result = false;
                }
            });



            return result;
        };
    
    $.extend(nfield, {
        validateOpenCategory: validateOpenCategory,
        validateRequiredOnOpen: validateRequiredOnOpen,
        validateOpenForUserButton: validateOpenForUserButton,
        validateRequiredOnCategoryList: validateRequiredOnCategoryList,
        validateCategoryListForUserButton: validateCategoryListForUserButton,
        validateValidNumberOnOpenNumeric: validateValidNumberOnOpenNumeric,
        validateFractionLengthOnOpenNumeric: validateFractionLengthOnOpenNumeric,
        validateMinMaxOnOpenNumeric: validateMinMaxOnOpenNumeric,
        validateRangeOnOpenNumeric: validateRangeOnOpenNumeric,
        validateMinMaxOnCategoryList: validateMinMaxOnCategoryList,
        validate: validate
    });

})(NFIELD, jQuery);


$(function () {

    $(".btn-primary").click(function (e) {

        if ($(e.target).is('a')) {
            return false;
        }

        var $card = $(this).parents('.card').eq(0);
        var valid = true;

        $card.find(".categorylist:visible").each(function() {
            var categoryList = $(this);
            var categoryListValid = true;
            if (categoryList.hasClass("required")) {

                // alert('1');

                var result = NFIELD.validate(categoryList, NFIELD.validateRequiredOnCategoryList);

                if (!result) {
                    categoryListValid = false;
                    valid =false;
                }                
            }
            if (categoryListValid && categoryList.hasClass("categories")) {
                // alert('2');
                if (!NFIELD.validate($(this), NFIELD.validateMinMaxOnCategoryList))
                    valid = false;
            }

        });
        $card.find(".open.required:visible").each(function() {
            // alert('3');
            if (!NFIELD.validate($(this), NFIELD.validateRequiredOnOpen))
                valid =false;
        });
        $card.find(".open.number:visible").each(function () {
            // alert('4');
            var validOpenNumber = NFIELD.validate($(this), NFIELD.validateValidNumberOnOpenNumeric);
            if (!validOpenNumber)
                valid = false;
            if (validOpenNumber && !NFIELD.validate($(this), NFIELD.validateFractionLengthOnOpenNumeric)) {
                validOpenNumber = false;
                valid = false;
            }
            if (validOpenNumber && !NFIELD.validate($(this), NFIELD.validateMinMaxOnOpenNumeric)) {
                validOpenNumber = false;
                valid = false;
            }
            if (validOpenNumber && !NFIELD.validate($(this), NFIELD.validateRangeOnOpenNumeric)) {
                valid = false;
            }
        });

        $card.find(".open.line:visible").each(function () {
            // alert('5');
            var validOpenLine = NFIELD.validate($(this), NFIELD.validateValidNumberOnOpenNumeric);
            if (!validOpenLine)
                valid = false;
            if (validOpenLine && !NFIELD.validate($(this), NFIELD.validateMinMaxOnOpenNumeric))
                valid = false;
        });

        $card.find(".category textarea.open:visible").each(function() {
            if (!NFIELD.validate($(this), NFIELD.validateOpenCategory))
                valid = false;
        });

        setTimeout(function() {

            if (valid === false) {
                if ($('.validation-message.error')[0].getBoundingClientRect().top < 0) {

                    $(window).scrollTo($('.validation-message:first'));

                }
            }

        }, 250);

        return valid;
    });

    $('input.button-clear').click(function () {

        $(".segment.active .validation-message").each(function() {
            var $item = $(this);
            $item.find(".message").text('');
            $item.slideUp().removeClass("error");
            
        });
    });

    $("div.group.text").each(function () {
        var $item = $(this);
        var $segment = $item.closest(".segment.active");
        $item.after($(".validation-message",$segment));
    }); 

    $('input[name*="button-user"]').click(function () {
        var valid = NFIELD.validate(".categorylist", NFIELD.validateCategoryListForUserButton, $(this));
        if (valid)
            valid = NFIELD.validate(".open", NFIELD.validateOpenForUserButton, $(this));

        console.log(valid + ' valid====');

        setTimeout(function() {

            if (valid === false) {
                if ($('.validation-message.error')[0].getBoundingClientRect().top < 0) {

                    $(window).scrollTo($('.validation-message:first'));

                }
            }

        }, 250);

        return valid;
    });
});