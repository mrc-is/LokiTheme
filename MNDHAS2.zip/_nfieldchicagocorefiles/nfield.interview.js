﻿/// <reference path="jquery-1.4.4.js" />

/*
*  Contains functionality for various behaviours of input items
*
*  Copyright (c) NIPO Software 2011
*/

$(document).ready(function () {

    $("form .group .open input, form .group .open textarea").first().focus();

    $(".categorylist").bind("updateStyle", function () {
        $("input:radio, input:checkbox").each(function () {
            var category = $(this).closest("div.category");

            if (this.checked)
                category.addClass("selected");
            else
                category.removeClass("selected");
        });
    });

    $(".categorylist").trigger("updateStyle");

    //
    // Prevents form submit on ENTER (unless in a textearea)
    $("form:first").keypress(function (event) {
        if (event.keyCode == 13) {
            var isTextArea = $(event.target).is("textarea");
            return isTextArea;
        }
        return true;
    });

    //
    // Default behavior for the clear button -> Clears the values of all elements in the first form
    // and removes the related styles
    $(".button-clear").unbind("click").click(function () {
        var wasSelected = $("form:first .selected");
        wasSelected.removeClass("selected");
        $("form:first input").each(function () {
            switch (this.type) {
                case 'text':
                    $(this).val('');
                    $(this).trigger("asifclicked");
                    break;
                case 'hidden':
                    if ($(this).hasClass("answerOrder")) {
                        $(this).val('');
                    }
                    break;
                case 'checkbox':
                case 'radio':
                    this.checked = false;
                    $(this).trigger("asifclicked");
                    break;
            }
        });
        wasSelected.trigger("asifclicked");

        $("form:first textarea").each(function () {
            $(this).val('');
            $(this).trigger("asifclicked");
        });

        $(".categorylist").trigger("updateStyle");

        $("form .group input, form .group textarea").first().focus();
        return false; // prevent default behavior
    });

    $(".category .open").keyup(function () {
        $(this).trigger("textupdated");
    });

    $(".category .open").mouseup(function (eventObject) {
        if (eventObject.button == 2) {
            var $this = $(this);
            setTimeout(function () { $this.trigger("textupdated"); }, 20);
        }
    });

    $(".category .open").bind("paste", function () {
        var $this = $(this);
        setTimeout(function () { $this.trigger("textupdated"); }, 20);
    });

    $(".category .open").bind("cut", function () {
        var $this = $(this);
        setTimeout(function () { $this.trigger("textupdated"); }, 20);
    });

    //
    // Make changes in an open code's textbox act like a click on the linked radiobutton or checkbox
    $(".category .open").bind("textupdated", function () {
        var id = $(this).attr("id");
        var text = $(this).val();

        id = id.substring(0, id.length - 5); // strip "-open"
        var needToUpdate = ($("#" + id).attr("checked") && text.length == 0)
            || (!$("#" + id).attr("checked") && text.length > 0);
        if (needToUpdate) {
            $("#" + id).attr('checked', text.length > 0);
            $("#" + id).trigger("asifclicked");
        }
    });

    // When clicking on container category propogate click to first input
    $("div.categorylist div.category-padding").click(function (event) {
        if (event.target.nodeName !== "INPUT" && event.target.nodeName !== "TEXTAREA") {
            $("input:checkbox.category", $(this)).each(function () {
                this.checked = !this.checked;

                $(this).trigger("asifclicked");
            });

            $("input:radio.category", $(this).closest("div.category")).each(function () {
                if (this.checked === false) {
                    this.checked = true;
                    $(this).trigger("asifclicked");
                }
            });
        }
        return true;
    });

    var getCategoryNumber = function (category) {
        return category.val().split('-').reverse().shift();
    }

    var getMentionedInput = function (list) {
        return $('#' + list.attr("id") + '-multi');
    }

    var clearMentionedCategories = function (list) {
        getMentionedInput(list).val("");
    }

    var getCurrentMentions = function (mentionedInput) {
        var mentionsValue = mentionedInput.val();
        if (!mentionsValue) {
            return [];
        }
        return mentionsValue.split(",");

    }
    var removeCategoryFromMentions = function(list, category) {
        var mentionedInput = getMentionedInput(list);
        var categoryNumber = getCategoryNumber(category);
        var mentions = getCurrentMentions(mentionedInput);

        if (mentions.indexOf(categoryNumber) >= 0) {
            mentions.splice(mentions.indexOf(categoryNumber), 1);
        }

        mentionedInput.val(mentions.join());
    }

    var addMentionedCategory = function(list, category) {
        var mentionedInput = getMentionedInput(list);
        var categoryNumber = getCategoryNumber(category);

        var mentions = getCurrentMentions(mentionedInput);
        if (mentions.indexOf(categoryNumber) < 0) {
            mentions.push(categoryNumber);
        }

        mentionedInput.val(mentions.join());
    }

    $(".categorylist input:checkbox").bind("asifclicked", function () {
        var list = $(this).closest(".categorylist");
        if (this.checked) {

            $("input:radio.category", list).each(function () {
                if (this.checked === true) {
                    this.checked = false;
                    $(this).trigger("asifclicked");
                }
            });
            addMentionedCategory(list, $(this));
        } else {
            removeCategoryFromMentions(list, $(this));
        }
        list.trigger("updateStyle");
        $(this).trigger("change");
    });

    //
    // Uncheck all radio options after click on checkbox
    $(".categorylist input:checkbox").click(function () {
        var id = $(this).attr("id");

        $("#text-for-" + id + ":first").focus();

        $(this).trigger("asifclicked");
    });

    $(".categorylist input:radio").bind("asifclicked", function () {
        var list = $(this).closest(".categorylist");

        if (!this.checked) {
            removeCategoryFromMentions(list, $(this));
            return;
        }
        var id = $(this).attr("id");

        clearMentionedCategories(list);
        $("input:radio.category", list).each(function () {
            if (id != $(this).attr("id")) {
                this.checked = false;
                $(this).trigger("asifclicked");
            }
        });

        $("input:checkbox.category", list).each(function () {
            if (this.checked === true) {
                this.checked = false;
                $(this).trigger("asifclicked");
            }
        });
        addMentionedCategory(list, $(this));

        list.trigger("updateStyle");
        $(this).trigger("change");
    });

    // Uncheck all checkbox and radio options, except for self, after click on radio
    $(".categorylist input:radio").click(function () {
        var id = $(this).attr("id");

        $("#text-for-" + id + ":first").focus();

        this.checked = true;

        $(this).trigger("asifclicked");
    });

    $(".categorylist div.category").mousedown(function () {
        $(this).addClass("pushed");
    }).mouseup(function () {
        $(this).removeClass("pushed");
    }).mouseout(function () {
        $(this).removeClass("pushed");
    });

    //
    //Fix required for IE to function as expected whenever an image is contained within a label
    $("label img").click(function () {
        $(this).closest("label").click();
    });


    $("div.line").each(function () {
        var $this = $(this);

        var id = $this.attr("id");
        $("#numeric-" + id).hide();

        var max = $this.attr("data-max");
        var value = $this.attr("data-value");

        $(this).slider({
            "range": "min",
            "max": max * 100,
            "value": value * 100,
            change: function () {
                $("#numeric-" + id).val($(this).slider("value") / 100);
            }
        });
    });

    $(".segment.active.sum-question").each(function () {
        var $this = $(this);

        var totalFieldSelector = "#" + $this.attr("data-total-field");
        var $total = $(totalFieldSelector);
        $total.attr("readonly", true);

        $("input.number:not(" + totalFieldSelector + ")", $this).addClass("sum-field");

        $("input.number.sum-field", $this).sum({
            bind: "keyup",
            selector: totalFieldSelector
        });

    });

    $(".segment.active.subtract-question").each(function () {
        var $this = $(this);

        var totalFieldSelector = "#" + $this.attr("data-total-field");
        var $total = $(totalFieldSelector);
        $total.val($total.attr("data-maximum"));
        $total.attr("readonly", true);

        $("input.number:not(" + totalFieldSelector + ")", $this).addClass("subtract-field");

        $("input.number.subtract-field", $this).subtract({
            bind: "keyup",
            selector: totalFieldSelector,
            total: parseInt($total.attr("data-maximum"))
        });

    });

});
