var theme = {};

theme.init = function() {
    // CHANGE BROWSER TAB TITLE
    $('head title').text('Survey on Housing 2022');
    /************************************************** */

    // link insert
    $('.style-997').each(function(){
        var link = $(this).text();
        $(this).html('<a href="'+link+'" target="_blank">'+link+'</a>');
    })
    // mailto link insert
    $('.style-998').each(function(){
        var link = $(this).text();
        $(this).html('<a href="mailto:'+link+'" target="_blank">'+link+'</a>');
    })

    // custom piping
    if ($('.segment').data('custompipe')){
        var values = $('.segment').data('custompipe').split('||');
        $('.segment[data-custompipe] input').each(function(i){
            $(this).val(values[i]).change();
        })
    }

    var customProgress = parseInt($('*[data-progress]').data('progress'));
    if (customProgress > 0) {
        $("#progress").removeAttr("style").width(customProgress + "%");
        $('#progressBar').append('<span id="progressText">'+customProgress+'%</span>');
    }
	 $(".complete .btn.button-clear").remove();
	 theme.functions.injectHTML();
}
theme.functions = {
 // allow the injection of HTML from texts in Odin script where the html is defined between [HTML] and [/HTML]
 // for example: do you see [HTML]<hr>[/HTML] the horizontal line here
 injectHTML: function() {
  var paragraphs =  $('.segment.active span');
  paragraphs.each(function() {
   var $this = $(this);
   if ($this.html().indexOf('[HTML]') !== -1) {
    var newhtml=$this.parent().html().replace(/\[HTML\]/g,'\<\/span\>').replace(/\[\/HTML\]/g, '\<span class="injected"\>').replace(/&lt;/g, '<').replace(/&gt;/g, '>') ;
    $this.parent().html(newhtml);
    $(".injected").attr("class", $this.attr("class"));
   }
  })
 }
}
